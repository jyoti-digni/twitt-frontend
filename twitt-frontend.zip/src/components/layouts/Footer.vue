<template>
  <footer class="border-t border-gray-800">
    <div
      class="container mx-auto max-w-7xl overflow-hidden px-6 py-16 sm:py-24 lg:px-8"
    >
      <nav class="flex place-content-center gap-12">
        <div class="pb-6">
          <router-link class="text-slate-400">Changelog</router-link>
        </div>
        <div class="pb-6">
          <router-link class="text-slate-400">Terms</router-link>
        </div>
        <div class="pb-6">
          <router-link class="text-slate-400">Privacy Policy</router-link>
        </div>
        <div class="pb-6">
          <router-link class="text-slate-400">Support</router-link>
        </div>
        <div class="pb-6">
          <router-link class="text-slate-400">Brand</router-link>
        </div>
      </nav>
      <div class="mt-10 flex space-x-10 sm:justify-center">
        <router-link class="text-slate-400 hover:text-slate-200 text-2xl"
          ><i class="fa-brands fa-x-twitter"></i
        ></router-link>
        <router-link class="text-slate-400 hover:text-slate-200 text-2xl"
          ><i class="fa-brands fa-github"></i
        ></router-link>
      </div>
      <p class="mt-10 text-xs text-slate-400 leading-5 sm:text-center">© 2024 Pinkary.</p>
      <p class="text-xs text-slate-400 leading-5 sm:text-center">v1.36.0</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>
