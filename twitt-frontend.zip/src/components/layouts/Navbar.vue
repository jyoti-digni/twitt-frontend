<template>
  <nav>
    <div
      class="fixed z-50 inset-0 h-0 px-4 flex justify-center md:justify-end md:px-4"
    >
      <div class="flex h-16 justify-end">
        <div v-if="authNavVisible" class="flex items-center space-x-2.5">
          <router-link to="/">
            <button
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-solid fa-house"></i>
            </button>
          </router-link>
          <router-link to="/code">
            <button
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-solid fa-code"></i>
            </button>
          </router-link>
          <router-link :to="`/@${username}`">
            <button
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-regular fa-user"></i>
            </button>
          </router-link>
          <router-link to="/bookmarks">
            <button
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-regular fa-bookmark"></i>
            </button>
          </router-link>
          <router-link to="/notifications">
            <button
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-regular fa-bell"></i>
            </button>
          </router-link>
          <div class="relative">
            <button
              @click="showMenu"
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-solid fa-bars"></i>
            </button>
            <div
              v-show="isMenuVisible"
              class="absolute top-8 right-0 bg-slate-900 text-slate-500 rounded-md shadow-lg mt-2 w-48"
            >
              <ul class="list-none p-2 space-y-1">
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/about">About</router-link>
                </li>
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/settings">Settings</router-link>
                </li>
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <button @click="logout">Log Out</button>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div v-else class="flex items-center space-x-2.5">
          <div class="relative">
            <button
              @click="showMenu"
              class="inline-flex items-center py-2 px-3 bg-slate-900 text-slate-500 hover:text-white rounded-md border border-transparent text-lg font-medium focus:outline-none"
            >
              <i class="fa-solid fa-bars"></i>
            </button>
            <div
              v-show="isMenuVisible"
              class="absolute top-8 right-0 bg-slate-900 text-slate-500 rounded-md shadow-lg mt-2 w-48"
            >
              <ul class="list-none p-2 space-y-1">
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/about">About</router-link>
                </li>
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/feed">Feed</router-link>
                </li>
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/login">Log in</router-link>
                </li>
                <li
                  class="hover:bg-slate-700 px-3 py-1 rounded-md cursor-pointer"
                >
                  <router-link to="/register">Register</router-link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  name: "Navbar",
  data() {
    return {
      isMenuVisible: false,
    };
  },
  computed: {
    ...mapGetters(["isAuthenticated", "getUser"]),
    username() {
      return this.getUser ? this.getUser.username : "";
    },
    authNavVisible() {
      return this.isAuthenticated;
    },
  },
  methods: {
    showMenu() {
      this.isMenuVisible = !this.isMenuVisible;
    },
    async logout() {
      await this.$store.dispatch("logout");
      this.$router.push("/");
    },
  },
  mounted() {},
};
</script>
