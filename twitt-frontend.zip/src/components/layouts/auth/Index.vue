<template>
  <div class="flex min-h-screen flex-col">
    <main class="flex-grow">
      <div class="fixed right-0 z-50">
        <Navbar />
      </div>
      <router-view></router-view>
    </main>

    <Footer />
  </div>
</template>

<script>
import Navbar from "../Navbar.vue";
import Footer from "../Footer.vue";
export default {
  name: "Index",
  components: {
    Navbar,
    Footer,
  },
};
</script>
