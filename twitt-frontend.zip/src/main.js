import { createApp } from "vue";
import "./style.css";
import App from "./App.vue";
import router from "./router";
import store from './store/store';
import { CkeditorPlugin } from '@ckeditor/ckeditor5-vue';

createApp(App).use(CkeditorPlugin).use(store).use(router).mount("#app");
