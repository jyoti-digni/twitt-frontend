<template>
  <router-view></router-view>
</template>

<script>
import axios from "./utils/axios";
export default {
  data() {
    return {
      token: null,
      getUser: null, // to store fetched user details
    };
  },
  async mounted() {
    await this.fetchAuthDetails();
  },
  methods: {
    async fetchAuthDetails() {
      try {
        const vuexState = JSON.parse(sessionStorage.getItem("vuex-state"));
        this.token = vuexState ? vuexState.token : null;
        console.log(this.token, "Token::");

        if (this.token) {
          const response = await axios.get("/auth-user-details", {
            headers: {
              Authorization: `Bearer ${this.token}`,
            },
          });
          console.log(response.data.userDetails, "responseofAuthUser");

          this.getUser = response.data.userDetails;
          this.$store.dispatch("login", {
            token: this.token,
            user: response.data.userDetails,
          });
        } else {
          console.error("Token not found.");
        }
      } catch (error) {
        console.error("Failed to fetch user details:", error);
      }
    },
  },
};
</script>
