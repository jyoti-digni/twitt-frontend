import { createStore } from "vuex";

function saveStateToSessionStorage(state) {
  sessionStorage.setItem("vuex-state", JSON.stringify(state));
}

function loadStateFromSessionStorage() {
  const savedState = sessionStorage.getItem("vuex-state");
  return savedState ? JSON.parse(savedState) : {};
}
const store = createStore({
  state() {
    return {
      ...loadStateFromSessionStorage(),
      user: null,
      token: null,
      isAuthenticated: false,
    };
  },
  // state: {
  //   user: null,
  //   token: null,
  //   isAuthenticated: false,
  // },
  mutations: {
    SET_USER(state, user) {
      state.user = user;
      state.isAuthenticated = true;
      saveStateToSessionStorage(state);
    },
    SET_TOKEN(state, token) {
      state.token = token;
      saveStateToSessionStorage(state);
    },
    LOGOUT(state) {
      (state.user = null),
      (state.token = null),
      (state.isAuthenticated = false);
      saveStateToSessionStorage(state);
    },
  },
  actions: {
    login({ commit }, { user, token }) {
      commit("SET_USER", user);
      commit("SET_TOKEN", token);
    },
    logout({ commit }) {
      commit("LOGOUT");
    },
  },

  getters: {
    isAuthenticated: (state) => state.isAuthenticated,
    getUser: (state) => state.user,
    getToken: (state) => state.token,
  },
});

export default store;
