<template>
  <main class="mt-16">
    <div class="flex flex-col items-center justify-center">
      <div class="w-full max-w-md overflow-hidden rounded-lg">
        <div class="flex justify-between space-x-2 mb-8">
          <button class="bg-pink-600 text-white px-4 py-2 rounded-md"
            @click.prevent="activeTab = 'FeedComponent'">
            <span class="icon"><i class="fa-solid fa-house"></i></span> Feed
          </button>
          <button class="bg-slate-900 px-4 py-2 rounded-md text-slate-500 hover:text-white"
            @click.prevent="activeTab = 'ForYouComponent'">
            <span class="icon"><i class="fa-regular fa-heart"></i></span> For you
          </button>
          <button class="bg-slate-900 px-4 py-2 rounded-md text-slate-500 hover:text-white"
            @click.prevent="activeTab = 'TrendingComponent'">
            <span class="icon"><i class="fa-solid fa-fire"></i></span> Trending
          </button>
          <button class="bg-slate-900 px-4 py-2 rounded-md text-slate-500 hover:text-white"
            @click.prevent="activeTab = 'SearchComponent'">
            <span class="icon"><i class="fa-solid fa-magnifying-glass"></i></span> Search
          </button>
        </div>
        <component :is="activeTab"></component>
      </div>
    </div>
  </main>

</template>

<script>
import IndexDashboard from "../../components/layouts/auth/Index.vue";
import FeedComponent from "./FeedComponent.vue";
import ForYouComponent from "./ForYouComponent.vue";
import TrendingComponent from "./TrendingComponent.vue";
import SearchComponent from "./SearchComponent.vue";

export default {
  name: "Dashboard",
  components: {
    IndexDashboard,
    FeedComponent,
    ForYouComponent,
    TrendingComponent,
    SearchComponent,
  },
  data() {
    return {
      activeTab: 'FeedComponent'
    }
  }

};
</script>
