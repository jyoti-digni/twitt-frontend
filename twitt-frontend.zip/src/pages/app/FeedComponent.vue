<template>
  <div class="mt-2" id="component1">
    <TwittForm :userId="12" @submitTwit="submitTwit" />
    <TwitDetail :twitts="twitts" />
  </div>
</template>

<script>
import TwittForm from "../twits/TwittForm.vue";
import TwitDetail from "../twits/TwitDetail.vue";
import axios from "../../utils/axios";
export default {
  name: "FeedComponent",
  components: {
    TwittForm,
    TwitDetail,
  },
  data() {
    return {
      twitts: [],
    };
  },
  async mounted() {
    await this.fetchTwitts();
  },
  methods: {
    async submitTwit(formData) {
      try {
        await axios.post("/twitt-create", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        this.fetchTwitts();
      } catch (error) {
        console.error("Error submitting twit:", error);
      }
    },
    async fetchTwitts() {
      const response = await axios.get("/fetch-twitt");
      this.twitts = response.data.twitts;
    },
  },
};
</script>
