<template>
    <h1>ForYou component</h1>

</template>

<script>
export default {
    name: 'ForYouComponent'
}
</script>