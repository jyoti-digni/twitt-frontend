<template>
  <div class="mb-8 w-full max-w-md">
    <div class="relative flex items-center">
      <i
        class="fa-solid fa-magnifying-glass absolute left-3 text-slate-400"
      ></i>
      <input
        type="text"
        class="w-full py-3 pl-10 pr-4 text-sm px-8 text-white caret-white bg-slate-950 border border-slate-800 rounded-2xl shadow-sm focus:outline-none focus:border-pink-500 placeholder-slate-500"
        placeholder="Search for users..."
      />
    </div>
  </div>
  <section class="max-w-2xl mb-8">
    <ul class="flex flex-col gap-3">
      <li v-for="(user, index) in users" :key="index">
        <router-link
          :to="`/@${user.username}`"
          class="group flex items-center rounded-xl border gap-3 border-slate-900 bg-slate-950 bg-opacity-80 p-4 transition-colors hover:bg-slate-900"
        >
          <figure
            class="rounded-full h-12 w-12 transition-opacity bg-slate-800"
          >
            <img
              class="rounded-full h-12 w-12 transition-opacity bg-slate-800"
              src="/images/default-avatar.png"
              alt=""
            />
          </figure>
          <div class="flex flex-col text-sm font-medium">
            <div class="flex items-center text-white">
              <p>{{ user.name }}</p>
            </div>
            <p class="text-slate-500">{{ user.username }}</p>
          </div>
        </router-link>
      </li>
    </ul>
  </section>
</template>

<script>
import axios from "../../utils/axios";
export default {
  name: "SearchComponent",
  data() {
    return {
      users: [],
    };
  },
  async mounted() {
    await this.getAllUsers();
  },
  methods: {
    async getAllUsers() {
      const response = await axios.get("/fetch-users");
      this.users = response.data.users;
    },
  },
};
</script>
