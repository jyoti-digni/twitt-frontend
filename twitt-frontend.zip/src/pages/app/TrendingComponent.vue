<template>
    <h1>Trending Component</h1>

</template>

<script>
export default {
    name: 'TrendingComponent'
}
</script>