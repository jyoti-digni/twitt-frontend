<template>
  <template>
    <div class="flex flex-col items-center mb-6 mt-20">
      <div class="w-full max-w-md px-2 sm:px-0">
        <h2 class="font-medium text-slate-200 text-2xl tracking-normal">
          Bookmark
        </h2>
      </div>
    </div>

    <main class="mt-16">
      <div class="flex flex-col justify-center items-center">
        <div class="max-w-md w-full min-h-screen overflow-hidden px-2 sm:px-0">
          <p class="text-slate-400">No bookmarks.</p>
        </div>
      </div>
    </main>
  </template>
</template>
</template>


<script>
export default {
  name: "Bookmark",
};
</script>