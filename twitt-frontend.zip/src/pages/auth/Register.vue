<template>
  <div>
    <a class="mt-20 flex justify-center">
      <img class="w-32" src="/images/logo.jpg" alt="Logo" />
    </a>
    <div class="container mx-auto w-full max-w-md px-4 py-10 sm:px-0">
      <form @submit.prevent="submitRegister">
        <div class="mb-4">
          <label for="name" class="block font-medium text-sm text-slate-500"
            >Name</label
          >
          <input
            type="text"
            name="name"
            v-model="form.name"
            class="text-white caret-white px-3 py-2 focus:border focus:border-pink-800 border border-slate-800 bg-slate-900 backdrop-blur-sm rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mb-4">
          <label for="username" class="block font-medium text-sm text-slate-500"
            >Username</label
          >
          <input
            type="text"
            name="username"
            v-model="form.username"
            class="text-white caret-white px-3 py-2 focus:border focus:border-pink-800 border border-slate-800 bg-slate-900 backdrop-blur-sm rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mb-4">
          <label for="email" class="block font-medium text-sm text-slate-500"
            >Email</label
          >
          <input
            type="email"
            v-model="form.email"
            class="text-white caret-white px-3 py-2 focus:border focus:border-pink-800 border border-slate-800 bg-slate-900 backdrop-blur-sm rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mb-4">
          <label for="password" class="block font-medium text-sm text-slate-500"
            >Password</label
          >
          <input
            type="text"
            name="password"
            v-model="form.password"
            class="text-white caret-white px-3 py-2 focus:border-pink-500 border border-slate-800 bg-slate-900 backdrop-blur-sm focus:ring-slate-900 rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>

        <div class="mb-4">
          <label
            for="confirm_password"
            class="block font-medium text-sm text-slate-500"
            >Confirm Password</label
          >
          <input
            type="text"
            name="password_confirmation"
            v-model="form.password_confirmation"
            class="text-white caret-white px-3 py-2 focus:border-pink-500 border border-slate-800 bg-slate-900 backdrop-blur-sm focus:ring-slate-900 rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mb-4 block">
          <label for="" class="flex items-center">
            <input type="checkbox" class="cursor-pointer text-2xl" />
            <span class="ml-2 text-sm text-slate-500 font-medium"
              >By signing up, I confirm that I am at least 18 years old and
              accept the
              <a href="" class="text-pink-500 underline">Terms of Service</a>
              and
              <a href="" class="text-pink-500 underline">Privacy Policy</a
              >.</span
            >
          </label>
        </div>
        <div class="mb-4 flex items-center justify-end">
          <span class="font-medium text-sm text-slate-500 mr-1"
            >Already have an account?</span
          >
          <router-link class="text-white text-sm underline leading-4" to="/login"
            >Sign in here?</router-link
          >
          <button
            type="submit"
            class="text-pink-500 border border-pink-500 px-4 py-2 rounded-lg text-sm ml-4"
          >
            Register
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "../../utils/axios";
export default {
  name: "Register",
  data() {
    return {
      form: {
        name: "",
        username: "",
        email: "",
        password: "",
        password_confirmation: "",
      },
    };
  },
  methods: {
    async submitRegister() {
      try {
        const formData = new FormData();
        formData.append("name", this.form.name);
        formData.append("username", this.form.username);
        formData.append("email", this.form.email);
        formData.append("password", this.form.password);
        formData.append(
          "password_confirmation",
          this.form.password_confirmation
        );

        await axios.post("/register", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
      } catch (error) {
        console.error("Error submitting form:", error);
      }
    },
  },
};
</script>
