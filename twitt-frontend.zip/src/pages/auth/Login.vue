<template>
  <div>
    <a class="mt-20 flex justify-center">
      <img class="w-32" src="/images/logo.jpg" alt="Logo" />
    </a>
    <div class="container mx-auto w-full max-w-md px-4 py-10 sm:px-0">
      <form action="" @submit.prevent="submitLoginForm">
        <div>
          <label for="" class="block font-medium text-sm text-slate-500"
            >Email</label
          >
          <input
            type="text"
            v-model="email"
            class="text-white caret-white px-3 py-2 focus:border focus:border-pink-800 border border-slate-800 bg-slate-900 backdrop-blur-sm rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mt-4">
          <label for="" class="block font-medium text-sm text-slate-500"
            >Password</label
          >
          <input
            type="password"
            v-model="password"
            class="text-white caret-white px-3 py-2 focus:border-pink-500 border border-slate-800 bg-slate-900 backdrop-blur-sm focus:ring-slate-900 rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
        <div class="mt-4 block">
          <label for="" class="flex items-center">
            <input
              type="checkbox"
              class="focus:ring-pink-500 size-4.5 text-pink-500 bg-slate-900 rounded cursor-pointer"
            />
            <span class="ml-2 text-sm text-slate-500">Remember me</span>
          </label>
        </div>
        <div class="mt-4 flex items-center justify-end">
          <router-link
            class="text-white text-sm underline leading-4"
            to="/forgot-password"
            >Forgot your password?</router-link
          >
          <button
            type="submit"
            class="text-pink-500 border border-pink-500 px-4 py-2 rounded-lg ml-4 text-sm"
          >
            Log In
          </button>
        </div>
      </form>
      <div class="py-8">
        <div class="border-t border-gray-800"></div>
      </div>
      <div class="mt-4 pb-12 flex items-center justify-center">
        <p class="font-medium text-sm text-slate-500 mr-1">
          Don't have an account?
        </p>
        <router-link
          class="text-white text-sm underline leading-4"
          to="/register"
          >Sign up here</router-link
        >
      </div>
    </div>
  </div>
</template>
<script>
import axios from "../../utils/axios";
import { useStore } from "vuex";

export default {
  name: "Login",
  data() {
    return {
      email: "",
      password: "",
    };
  },
  methods: {
    async submitLoginForm() {
      try {
        const response = await axios.post("/login", {
          email: this.email,
          password: this.password,
        });
        this.$store.dispatch("login", {
          token: response.data.token,
          user: response.data.user,
        });
        this.$router.push("/");
      } catch (error) {
        console.error("Login failed:", error);
        alert("Invalid credentials, please try again.");
      }
    },
  },
};
</script>
