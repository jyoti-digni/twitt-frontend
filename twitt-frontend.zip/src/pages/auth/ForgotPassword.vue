<template>
     <div>
    <a class="mt-20 flex justify-center">
      <img class="w-32" src="/images/logo.jpg" alt="Logo" />
    </a>
  
    <div class="container mx-auto w-full max-w-md px-4 py-10 sm:px-0">
        <div class="mb-4 text-sm text-slate-400">
            Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.
        </div>
      <form action="">
        <div>
          <label for="email" class="block font-medium text-sm text-slate-500"
            >Email</label
          >
          <input
            type="text"
            class="text-white caret-white px-3 py-2 focus:border focus:border-pink-800 border border-slate-800 bg-slate-900 backdrop-blur-sm rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
          />
        </div>
       
        <div class="mt-4 flex items-center justify-end"> 
          <button class="text-pink-500 border border-pink-500 px-4 py-2 rounded-lg ml-4 text-sm">Email Password Reset Link</button>
        </div>
      </form>
      

    </div>
  </div>

</template>

<script>
export default {
    name: 'ForgotPassword'
}
</script>