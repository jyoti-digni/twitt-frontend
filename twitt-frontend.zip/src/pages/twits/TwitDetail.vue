<template>
  <article class="my-12" v-for="(twitt, index) in twitts" :key="index">
    <div class="bg-slate-900 hover:bg-slate-800 rounded-xl p-4">
      <!-- Header Section -->
      <div class="flex justify-between items-center">
        <div class="flex items-center">
          <img
            src="/images/default-avatar.png"
            alt="User avatar"
            class="h-10 w-10 rounded-full"
          />
          <div class="ml-3">
            <h3 class="text-white text-sm">{{ twitt.user.name }}</h3>
            <span class="text-slate-500 text-sm"
              >@{{ twitt.user.username }}</span
            >
          </div>
        </div>
        <div class="relative text-slate-400">
          <button class="text-sm" @click="toggleMenu(twitt.id)">
            <i class="fa-solid fa-ellipsis"></i>
          </button>
          <div
            class="absolute right-0 top-8 w-48 mt-2 bg-slate-900 text-slate-500 rounded-md shadow-lg"
            v-if="activeMenuId === twitt.id"
          >
            <ul class="p-2 space-y-1">
              <li
                class="cursor-pointer rounded-md hover:bg-slate-700 px-3 py-1"
              >
                <router-link class="text-sm flex items-center space-x-2">
                  <i class="fa-solid fa-thumbtack text-white"></i>
                  <span>Pin</span>
                </router-link>
              </li>
              <li
                class="cursor-pointer rounded-md hover:bg-slate-700 px-3 py-1"
              >
                <button
                  class="text-sm flex items-center space-x-2"
                  @click="openEditModal(twitt)"
                >
                  <i class="fa-solid fa-pen"></i>
                  <span>Edit</span>
                </button>
                <div
                  v-if="showModal"
                  class="fixed inset-0 flex items-center justify-center z-50"
                >
                  <div class="absolute inset-0 bg-slate-900"></div>
                  <div
                    class="relative bg-slate-950 text-white rounded-lg max-w-xl w-1/4 p-2 sm:p-10 z-50 bottom-36 pt-16"
                  >
                    <button
                      class="absolute right-3 top-3 text-slate-400 hover:text-slate-100 focus:outline-none"
                      @click="closeEditModal()"
                    >
                      <svg
                        class="h-6 w-6"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        aria-hidden="true"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M6 18 18 6M6 6l12 12"
                        ></path>
                      </svg>
                    </button>
                    <div class="space-y-6">
                      <h2 class="text-lg font-medium text-slate-50">
                        Edit Answer
                      </h2>
                      <div class="border-l border-slate-900">
                        <form @submit.prevent="handleTwitEditSubmit">
                          <div class="mt-4 flex items-center justify-between">
                            <div class="w-full">
                              <div class="mb-1">
                                <label
                                  for="answer_question_9cdf8873-da45-40a4-b3bb-c78ce1a0ef41"
                                  class="sr-only"
                                  >Answer</label
                                >
                                <textarea
                                  id="answer_question_9cdf8873-da45-40a4-b3bb-c78ce1a0ef41"
                                  class="h-24 w-full resize-none border-none p-3 bg-transparent placeholder:text-slate-500 text-white focus:outline-none focus:ring-0"
                                  placeholder="Write your answer..."
                                  maxlength="1000"
                                  v-model="currentTwit.content"
                                  rows="3"
                                ></textarea>
                                <!-- <div
                                  v-if="
                                    currentTwit.images &&
                                    currentTwit.images.length > 0
                                  "
                                >
                                  <div class="py-4">
                                    <p>
                                      {{
                                        `/storage/twit_images/${twitt.images[0].filename}`
                                      }}
                                    </p>
                                  </div>
                                </div> -->

                                <p class="text-right text-xs text-slate-400">
                                  <span>11</span> / 1000
                                </p>
                              </div>

                              <div
                                class="flex items-center justify-between gap-4"
                              >
                                <div class="items center ml-2 flex gap-4">
                                  <button
                                    type="submit"
                                    class="inline-flex items-center px-4 py-2 border rounded-lg font-semibold text-xs tracking-widest hover:bg-gray-900 focus:outline-none focus:ring-0 focus:ring-offset-0 transition ease-in-out duration-150 text-blue-500 border-blue-500"
                                  >
                                    Send
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              <li
                class="cursor-pointer rounded-md hover:bg-slate-700 px-3 py-1"
              >
                <button
                  class="text-sm flex items-center space-x-2"
                  @click="deleteTwit(twitt.id)"
                >
                  <i class="fa-solid fa-trash"></i>
                  <span>Delete</span>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div v-if="twitt.images && twitt.images.length > 0">
        <div class="py-4">
          <img :src="twitt.images[0].image_path" alt="Twit Image" />
        </div>
      </div>

      <div class="py-3">
        <p class="text-white">{{ twitt.content }}</p>
      </div>
      <div
        class="mt-2 flex justify-between items-center text-sm text-slate-500"
      >
        <div class="flex items-center gap-2">
          <a
            href="#"
            class="transition-colors focus:outline-none hover:text-pink-500"
          >
            <i class="fa-regular fa-message"></i>
          </a>
          <span>·</span>
          <button
            class="transition-colors px-4 py-2 rounded focus:outline-none"
            @click="twitLike(twitt.id)"
          >
            <i class="fa-regular fa-heart"></i>
          </button>
          <span>·</span>
          <p class="cursor-help inline-flex items-center">
            <i class="fa-regular fa-eye"></i>
          </p>
        </div>
        <div class="flex items-center gap-2">
          <time :datetime="twitt.created_at">{{
            formatTime(twitt.created_at)
          }}</time>
          <span>·</span>
          <button
            class="transition-colors hover:text-slate-400 focus:outline-none"
          >
            <i class="fa-regular fa-bookmark"></i>
            <!-- <i class="fa-solid fa-bookmark"></i> -->
          </button>
          <span>·</span>
          <button
            title="Share"
            class="transition-colors duration-150 ease-in-out hover:text-slate-400 focus:outline-none"
          >
            <i class="fa-solid fa-share"></i>
          </button>
        </div>
      </div>
    </div>
  </article>
</template>

<script>
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import axios from "../../utils/axios";
import { mapGetters } from "vuex";

dayjs.extend(relativeTime);

export default {
  name: "TwitDetail",
  data() {
    return {
      showMenu: false,
      activeMenuId: null,
      showModal: false,
      currentTwit: null,
    };
  },
  props: {
    twitts: {
      type: Array,
      required: true,
    },
  },
  computed: {
    ...mapGetters(["isAuthenticated", "getUser"]),
    userId() {
      return this.getUser ? this.getUser.id : "";
    },
  },
  methods: {
    openEditModal(twitt) {
      this.currentTwit = { ...twitt };
      console.log(twitt.images[0], "IMAGEpATHH::");
      this.showModal = true;
    },
    closeEditModal() {
      this.showModal = false;
    },
    showMenuItem() {
      this.showMenu = !this.showMenu;
    },
    toggleMenu(id) {
      this.activeMenuId = this.activeMenuId === id ? null : id;
      console.log(this.activeMenuId, "activeMenuId");
    },
    formatTime(date) {
      return dayjs(date).fromNow();
    },
    async twitLike(twitId) {
      try {
        console.log(twitId, "twitId");
        const userId = this.userId;
        if (!userId) {
          console.error("User ID is not available");
          return;
        }
        const response = await axios.post("add-like", {
          user_id: userId,
          twit_id: twitId,
        });
      } catch (error) {
        console.error("Error adding like:", error);
      }
    },
    async deleteTwit(twitId) {
      try {
        console.log(twitId, "twitId");
        console.log(this.twitts, "TwittsRecordsForDelete::");
        await axios.delete(`/delete/twit/${twitId}`);
        const index = this.twitts.findIndex((twit) => twit.id === twitId);
        if (index !== 1) {
          this.twitts.splice(index, 1);
        }
      } catch (error) {
        console.error("Error submitting twit", error);
      }
    },

    async handleTwitEditSubmit() {
      try {
        const response = await axios.put(
          `/update/twit/${this.currentTwit.id}`,
          {
            content: this.currentTwit.content,
            user_id: this.currentTwit.user_id,
          }
        );

        const index = this.twitts.findIndex(
          (twit) => twit.id === this.currentTwit.id
        );
        if (index !== -1) {
          this.twitts[index] = response.data.updatedTwit;
        }
        this.showModal = false;
      } catch (error) {
        console.error("Error submitting twitt", error);
      }
    },
  },
};
</script>
