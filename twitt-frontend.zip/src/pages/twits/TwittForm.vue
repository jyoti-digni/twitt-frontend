<template>
    <div class="mb-12 pt-4">
        <form @submit.prevent="submitForm">
            <div class="relative group/menu">
                <div class="">
                    <textarea placeholder="Share an update..." v-model="form.content"
                        class="w-full px-4 py-3 text-white border border-slate-800 rounded-lg shadow-sm bg-slate-900/50 caret-white focus:border-pink-500 backdrop-blur-sm sm:text-sm"></textarea>
                </div>
                <div class="absolute top-0 right-0 mt-2 mr-2 hidden group-hover/menu:inline-block">
                    <button title="Upload an image"
                        class="rounded-md bg-slate-800 text-sm text-slate-400 px-2 py-1 hover:text-pink-500"
                        onclick="document.getElementById('image').click();">
                        <i class="fa-solid fa-camera"></i>
                    </button>
                    <input type="file" id="image" @change="handleFileUpload" class="hidden" accept="image/*" />
                </div>
            </div>
            <div class="mt-4 flex items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <button type="submit"
                        class="inline-flex items-center px-4 py-2 border text-pink-500 border-pink-500 rounded-lg font-semibold text-xs tracking-widest hover:bg-pink-900/20 focus:outline-none focus:ring-0 focus:ring-offset-0 transition ease-in-out duration-150">
                        Send
                    </button>
                </div>
            </div>
        </form>
    </div>

</template>

<script>
export default {
    name: 'TwittForm',
    props: ['userId'],
    data() {
        return {
            form: {
                content: "",
                user_id: this.userId,
                image: null,
            },
        }
    },
    methods: {
        async handleFileUpload(event) {
            this.form.image = event.target.files[0];
        },
        async submitForm() {
            console.log(this.userId, 'TwittUserIdddddd::::::');
            try {
                const formData = new FormData();
                formData.append("content", this.form.content);
                formData.append("image", this.form.image);
                formData.append("user_id", this.form.user_id);
                const response = await this.$emit("submitTwit", formData);
            } catch (error) {
                console.error("Error submitting twit:", error);
            }
        },
    }
}
</script>