<template>
  <div class="flex flex-col items-center justify-center py-10">
    <div
      class="w-full max-w-md min-h-screen overflow-hidden rounded-lg shadow-md px-4 md:px-0"
    >
      <div>
        <div class="relative p-5 text-center text-white bg-gradient-to-r">
          <div class="absolute top-6 left-0 flex space-x-2">
            <button
              class="flex items-center justify-center w-10 h-10 text-xl text-slate-400 transition duration-150 ease-in-out bg-slate-900 rounded-lg hover:text-white hover:bg-slate-800"
            >
              <i class="fa-solid fa-share-nodes"></i>
            </button>
            <button
              class="flex items-center justify-center w-10 h-10 text-xl text-slate-400 transition duration-150 ease-in-out bg-slate-900 rounded-lg hover:text-white hover:bg-slate-800"
            >
              <i class="fa-solid fa-qrcode"></i>
            </button>
          </div>

          <div class="relative mx-auto w-24 h-24">
            <img
              src="/images/default-avatar.png"
              alt="Avatar"
              class="mx-auto mb-3 rounded-full w-full h-full cursor-pointer"
            />
            <button
              class="absolute top-0 right-0 py-1 px-2 text-slate-300 bg-slate-900 rounded transition duration-150 ease-in-out hover:bg-slate-800 hover:text-white"
            >
              <i class="fa-solid fa-camera"></i>
            </button>
          </div>

          <div class="flex justify-center items-center">
            <h2 class="text-2xl font-bold">Test</h2>
          </div>
          <a href="#" class="text-slate-400">
            <p class="text-sm">username</p>
          </a>
          <a href="#" class="text-sm text-slate-500 hover:underline">
            Tell people about yourself
          </a>
          <div class="mt-2 text-sm text-slate-400">
            <p>
              <span class="cursor-help">1 View</span>
            </p>
          </div>
        </div>
        <template v-if="userLinks">
          <ul class="space-y-3">
            <li
              class="relative h-12 hover:darken-gradient group flex bg-gradient-to-r overflow-hidden from-blue-500 to-purple-600 rounded-lg"
              v-for="(userLink, index) in userLinks"
              :key="index"
            >
              <div
                class="absolute left-0 sm:-left-10 top-0 bottom-0 flex w-11 cursor-move items-center justify-center text-slate-300 opacity-50 hover:opacity-100 focus:outline-none group-hover:left-0 transition-all duration-500 z-10"
              >
                <i class="fa-solid fa-bars"></i>
              </div>
              <div
                class="flex-grow flex items-center justify-center transition-all duration-500 group-hover:-translate-x-full"
              >
                <a
                  class="flex items-center justify-center w-full p-4 text-sm font-bold text-white transition duration-300 ease-in-out rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:bg-opacity-75"
                >
                  {{ userLink.description }}
                </a>
              </div>
              <div
                class="absolute right-0 sm:-right-10 top-0 bottom-0 flex w-11 cursor-pointer items-center justify-center text-slate-300 opacity-50 hover:opacity-100 focus:outline-none transition-all duration-500 z-10 group-hover:right-0"
              >
                <i class="fa-solid fa-angles-right"></i>
              </div>
              <div
                class="absolute -right-56 top-0 bottom-0 flex items-center justify-center transition-all duration-500 z-5 group-hover:inset-0"
              >
                <div
                  class="min-w-fit cursor-help items-center gap-1 text-xs"
                  title="Clicked 0 times"
                >
                  0 clicks
                </div>

                <button
                  type="button"
                  class="flex w-10 justify-center text-slate-300 opacity-50 hover:opacity-100 focus:outline-none"
                >
                  <i class="fa-regular fa-eye"></i>
                </button>

                <button
                  type="button"
                  class="flex w-10 justify-center text-slate-300 opacity-50 hover:opacity-100 focus:outline-none"
                  @click="openEditModal(userLink)"
                >
                  <i class="fa-solid fa-pen"></i>
                </button>
                <div
                  v-if="showModal"
                  class="fixed inset-0 flex items-center justify-center z-50"
                >
                  <div class="absolute inset-0 bg-slate-900"></div>
                  <div
                    class="relative bg-slate-950 text-white rounded-lg shadow-xl max-w-xl w-full p-6 sm:p-10 z-50 bottom-36"
                  >
                    <button
                      @click="closeEditModal"
                      class="absolute right-3 top-3 text-slate-400 hover:text-slate-100 focus:outline-none"
                    >
                      <svg
                        class="h-6 w-6"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        aria-hidden="true"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M6 18 18 6M6 6l12 12"
                        ></path>
                      </svg>
                    </button>
                    <div class="space-y-6">
                      <form @submit.prevent="handleEditSubmit">
                        <div class="space-y-4">
                          <div>
                            <label
                              class="block text-sm font-medium text-slate-500"
                              for="description"
                            >
                              Description
                            </label>
                            <input
                              id="description"
                              v-model="currentLink.description"
                              type="text"
                              class="mt-1 block w-full rounded-lg px-3 bg-slate-900/50 py-2 text-sm text-white focus:border-pink-500 border border-slate-800 shadow-sm"
                            />
                          </div>
                          <div>
                            <label
                              class="block text-sm font-medium text-slate-500"
                              for="url"
                            >
                              URL
                            </label>
                            <input
                              id="url"
                              type="text"
                              v-model="currentLink.link"
                              class="mt-1 block w-full rounded-lg px-3 bg-slate-900/50 py-2 text-sm text-white caret-white focus:border-pink-500 border border-slate-800 shadow-sm"
                            />
                            <p class="mt-2 text-sm text-slate-600 hidden">
                              Editing the URL will reset the click counter to
                              zero
                            </p>
                          </div>
                        </div>
                        <div class="flex items-center gap-4 mt-6">
                          <button
                            type="submit"
                            class="px-4 py-2 text-sm font-semibold text-blue-500 border border-blue-500 rounded-lg hover:bg-slate-800 focus:outline-none transition duration-150"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            @click="closeEditModal"
                            class="text-sm text-slate-600 hover:text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <button
                  type="submit"
                  @click="deleteUserLink(userLink.id)"
                  class="flex w-10 justify-center text-slate-300 opacity-50 hover:opacity-100 focus:outline-none"
                >
                  <i class="fa-regular fa-trash-can"></i>
                </button>
              </div>
            </li>
          </ul>
        </template>
        <template v-else>
          <div class="py-5">
            <p class="mx-2 text-center text-slate-500">
              No links yet. Add your first link!
            </p>
          </div>
        </template>
        <div class="py-8">
          <div class="flex gap-2">
            <button
              @click="showLinkForm"
              class="flex items-center justify-center w-full px-4 py-2 text-sm font-bold text-white transition duration-300 ease-in-out rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:darken-gradient basis-4/5"
            >
              <span class="mr-2"><i class="fa-solid fa-plus"></i></span> Add New
              Link
            </button>
            <button
              class="flex items-center justify-center w-10 h-10 px-12 text-sm font-bold text-white transition duration-300 ease-in-out rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:darken-gradient"
            >
              <i class="fa-solid fa-gear"></i>
            </button>
          </div>
        </div>

        <div class="mb-12 pt-4" v-if="isHidden">
          <form @submit.prevent="submitLinkForm">
            <div class="mb-4">
              <label
                for="description"
                class="block font-medium text-sm text-slate-500"
                >Description</label
              >
              <input
                type="text"
                name="description"
                v-model="userLinkForm.description"
                class="text-white caret-white px-3 py-2 focus:border-pink-500 border border-slate-800 bg-slate-900 backdrop-blur-sm focus:ring-slate-900 rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
              />
            </div>
            <div class="mb-4">
              <label for="link" class="block font-medium text-sm text-slate-500"
                >URL</label
              >
              <input
                type="text"
                name="link"
                v-model="userLinkForm.link"
                class="text-white caret-white px-3 py-2 focus:border-pink-500 border border-slate-800 bg-slate-900 backdrop-blur-sm focus:ring-slate-900 rounded-lg shadow-sm sm:text-sm mt-1 block w-full"
              />
            </div>
            <div class="mt-4 flex items-center justify-between gap-4">
              <div class="flex items-center gap-4">
                <button
                  type="submit"
                  class="inline-flex items-center px-4 py-2 border text-blue-500 border-blue-500 rounded-lg font-semibold text-xs tracking-widest hover:bg-blue-900/20 focus:outline-none focus:ring-0 focus:ring-offset-0 transition ease-in-out duration-150"
                >
                  Create
                </button>
                <button
                  type="submit"
                  @click="cancelForm"
                  class="inline-flex items-center px-4 py-2 text-slate-400 rounded-lg hover:text-slate-800 font-semibold text-xs tracking-widest focus:outline-none focus:ring-0 focus:ring-offset-0 transition ease-in-out duration-150"
                >
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
        <TwittForm :userId="this.userId" @submitTwit="submitTwit" />
        <TwitDetail :twitts="twitts" />
      </div>
    </div>
  </div>
</template>

<script>
import axios from "../../utils/axios";
import TwitDetail from "./TwitDetail.vue";
import TwittForm from "./TwittForm.vue";
import { mapGetters } from "vuex";

export default {
  name: "TwittCreate",
  data() {
    return {
      isHidden: false,
      showModal: false,
      currentLink: null,
      userLinkForm: {
        description: "",
        link: "",
      },
      userLinks: [],
      twitts: [],
    };
  },
  components: {
    TwitDetail,
    TwittForm,
  },
  async mounted() {
    await this.fetchUserLinks();
    await this.fetchTwitts();
  },
  computed: {
    ...mapGetters(["getUser"]),
    userId() {
      console.log(this.getUser, 'this.getUser');
      return this.getUser ? this.getUser.id : "";
    },
  },
  methods: {
    async submitLinkForm() {
      try {
        const linkData = new FormData();
        linkData.append("description", this.userLinkForm.description);
        linkData.append("link", this.userLinkForm.link);
        linkData.append("user_id", this.userId);
        await axios.post("/create/user-link", linkData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        this.fetchUserLinks();
        this.userLinkForm.description = "";
        this.userLinkForm.link = "";
        this.userLinkForm.user_id = "";
        this.isHidden = false;
      } catch (error) {
        console.error("Error submittong twit:", error);
      }
    },
    openEditModal(userLink) {
      this.currentLink = { ...userLink };
      console.log(this.currentLink);
      this.showModal = true;
    },
    closeEditModal() {
      this.showModal = false;
    },
    async submitTwit(formData) {
      try {
        await axios.post("/twitt-create", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        this.fetchTwitts();
      } catch (error) {
        console.error("Error submitting twit:", error);
      }
    },
    async fetchUserLinks() {
      const response = await axios.get("/fetch-user-link");
      this.userLinks = response.data.userLinks;
    },
    async fetchTwitts() {
      const response = await axios.get("/fetch-twitt");
      this.twitts = response.data.twitts;
    },
    async showLinkForm() {
      this.isHidden = !this.isHidden;
    },
    async cancelForm() {
      this.isHidden = !this.isHidden;
    },

    async handleEditSubmit() {
      try {
        const response = await axios.put(
          `/update/user-link/${this.currentLink.id}`,
          {
            description: this.currentLink.description,
            link: this.currentLink.link,
            user_id: this.currentLink.user_id,
          }
        );
        const index = this.userLinks.findIndex(
          (link) => link.id === this.currentLink.id
        );
        if (index !== -1) {
          this.userLinks[index] = response.data.updatedLink;
        }
        this.showModal = false;
      } catch (error) {
        console.error("Error submitting userlink", error);
      }
    },
    async deleteUserLink(userLinkId) {
      try {
        await axios.delete(`/delete/user-link/${userLinkId}`);
        const index = this.userLinks.findIndex(
          (link) => link.id === userLinkId
        );
        if (index !== -1) {
          this.userLinks.splice(index, 1);
        }
      } catch (error) {
        console.error("Error submitting userLink", error);
      }
    },
  },
};
</script>
