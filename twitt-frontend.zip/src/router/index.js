import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    path: "/",
    component: () => import("../components/layouts/auth/Index.vue"),
    children: [
      {
        path: "/",
        component: () => import("../pages/app/Dashboard.vue"),
      },
      {
        path: "/@:username",
        component: () => import("../pages/twits/TwittCreate.vue"),
        props: true,
      },
      {
        path: "register",
        component: () => import("../pages/auth/Register.vue"),
      },
      {
        path: "login",
        component: () => import("../pages/auth/Login.vue"),
      },
      {
        path: "forgot-password",
        component: () => import("../pages/auth/ForgotPassword.vue"),
      },
      {
        path: "users",
        component: () => import("../pages/app/SearchComponent.vue"),
      },
      {
        path: "/notifications",
        component: () => import("../pages/app/Notifications.vue"),
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
